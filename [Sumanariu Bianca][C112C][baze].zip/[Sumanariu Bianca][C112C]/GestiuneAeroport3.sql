﻿

create database GestiuneAeroport3
ON PRIMARY
(
Name = PrimaryData,
FileName = 'C:\DataBase3\Primary.mdf',
size = 10MB, -- KB, Mb, GB, TB
maxsize = unlimited,
filegrowth = 1GB
),
FILEGROUP fgCurrent
(
Name = DataA,
FileName = 'C:\DataBase3\GroupA.ndf',
size = 10MB, -- KB, Mb, GB, TB
maxsize = unlimited,
filegrowth = 1GB
),
(
Name = DataB,
FileName = 'C:\DataBase3\GroupB.ndf',
size = 10MB, -- KB, Mb, GB, TB
maxsize = unlimited,
filegrowth = 1GB
),
FILEGROUP fgArchive
(
Name = ArchiveData,
FileName = 'C:\DataBase3\Archive.ndf',
size = 10MB, -- KB, Mb, GB, TB
maxsize = unlimited,
filegrowth = 1GB
)
LOG ON
(
Name = DataLog,
FileName = 'C:\DataBase3\Log.ldf',
size = 10MB, -- KB, Mb, GB, TB
maxsize = unlimited,
filegrowth = 1024MB)


create table Companii
   	(ID_companie int IDENTITY(1,1) primary key,
   	nume_companie varchar(20));


create table Avioane
	(ID_avion int primary key,
 	model varchar(20),
 	capacitate int,
 	ID_companie int,
 	CONSTRAINT FK_ID_companie_ FOREIGN KEY (ID_companie) REFERENCES 	Companii(ID_companie));

select*
from Avioane


 create table Tari  
 (ID_tara int IDENTITY(1,1) primary key,
  nume_tara varchar(20));

  create table Locatii
  (ID_locatie int IDENTITY(1,1) primary key,
   ID_tara int ,
   nume_locatie varchar(20),
   constraint ID_tara_fk foreign key(ID_tara) references Tari(ID_tara)  ON UPDATE CASCADE ON DELETE CASCADE);

	create table Calatori
	(
	 ID_calator int IDENTITY(1,1) primary key,
	 CNP varchar(13),
	 nume varchar(20),
	 prenume varchar(20),
	 sex varchar(10),
	 email varchar(20),
	 telefon varchar(15),
	 adresa varchar(30),
	 constraint CNP_UQ unique(CNP),
	 constraint NUME_nn check(NUME is not null), 
	 constraint SEX_CK check(SEX in('FEMININ', 'MASCULIN')));

	  

	 create table Clase
	 (ID_clasa int IDENTITY(1,1) primary key,
	 NUME_CLASA varchar(10)constraint NUME_CLASA_CK check(NUME_CLASA in('ECONOMIC', 'BUSINESS')));

	 create table Aeroporturi
	(ID_aeroport int IDENTITY(1,1) primary key,
	nume varchar(50),
	ID_oras int,
	constraint FK_ID_locatie foreign key(ID_oras) references Locatii(ID_locatie)   ON UPDATE CASCADE ON DELETE CASCADE
	);


	create table Gates
	(
	ID_gate int IDENTITY(1,1) primary key,
	numar int
	);
	
	
	create table Zboruri
	( ID_zbor int IDENTITY(1,1) primary key,
	ID_avion int,
	ora time,
	data_plecare date,
	durata int,
	ID_aeroport int,
	constraint FK_ID_avion foreign key(ID_avion) references Avioane(ID_avion)   ON 	UPDATE CASCADE ON DELETE CASCADE,
	constraint FK_ID_aeroport foreign key(ID_aeroport) references 	Aeroporturi(ID_aeroport) ON UPDATE CASCADE ON DELETE CASCADE);

	CREATE TABLE ZboruriGates
	(
    ID_zbor INT,
    ID_gate INT,
    PRIMARY KEY (ID_zbor, ID_gate),
    constraint FK_ID_zbor_ FOREIGN KEY (ID_zbor) REFERENCES Zboruri(ID_zbor) ON DELETE CASCADE,
    constraint FK_ID_gate FOREIGN KEY (ID_gate) REFERENCES Gates(ID_gate) ON DELETE CASCADE
);

	  create table Bilete
	 ( 
	  ID_bilet int IDENTITY(1,1) primary key,
	  ID_calator int,
	  ID_clasa int,
	  pret_bilet int,
	  constraint FK_ID_calator foreign key(ID_calator) references Calatori(ID_calator)   ON UPDATE CASCADE ON DELETE CASCADE,
	  constraint FK_ID_CLASA foreign key(ID_clasa) references Clase(ID_clasa)   ON UPDATE CASCADE ON DELETE CASCADE
	 );

	 CREATE TABLE BiletePerZbor (
	 ID_biletperzbor INT IDENTITY(1,1) PRIMARY KEY,
    id_bilet INT NOT NULL,
    id_zbor INT NOT NULL,
    constraint FK_ID_bilet FOREIGN KEY (id_bilet) REFERENCES Bilete(ID_bilet)   ON UPDATE CASCADE ON DELETE CASCADE,
    constraint FK_ID_zbor FOREIGN KEY (id_zbor) REFERENCES  Zboruri(ID_zbor)  ON UPDATE CASCADE ON DELETE CASCADE
);

   create table Staff (
   ID_staff INT IDENTITY(1,1) PRIMARY KEY,
   nume VARCHAR(50) NOT NULL,
   prenume VARCHAR(50) NOT NULL,
   email VARCHAR(100) UNIQUE NOT NULL,
   telefon VARCHAR(20),
);

create table Tasks
(
ID_task int IDENTITY(1,1) primary key,
nume varchar(50)
);

create table TasksperZbor
(
	ID_zbor int,
	ID_task int,
	FOREIGN KEY (ID_zbor) REFERENCES  Zboruri(ID_zbor)  ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (ID_task) REFERENCES  Tasks(ID_task)  ON UPDATE CASCADE ON DELETE CASCADE
);

create table StaffTasks
(
ID_StaffTask int identity (1,1) primary key,
ID_staff int,
ID_task int, 
constraint FK_ID_staff foreign key(ID_staff) references Staff(ID_staff)  ON UPDATE CASCADE ON DELETE CASCADE,
constraint FK_ID_task foreign key(ID_task) references Tasks(ID_task)  ON UPDATE CASCADE ON DELETE CASCADE
);


create table Departamente
(
ID_departament int IDENTITY(1,1) primary key,
denumire varchar(50),
utilitate varchar(50)
);

create table Functii
(
ID_functie int IDENTITY(1,1) primary key,
nume varchar(50) not null,
salariu_brut int,
ID_departament int,
constraint FK_ID_departament foreign key(ID_departament) references Departamente(ID_departament)  ON UPDATE CASCADE ON DELETE CASCADE
);

create table Repartizare_functii
(
ID_istoric int IDENTITY(1,1) primary key,
ID_staff int,
ID_functie int,
constraint FK_ID_staff_ foreign key(ID_staff) references Staff(ID_staff)  ON UPDATE CASCADE ON DELETE CASCADE,
constraint FK_ID_functie foreign key(ID_functie) references Functii(ID_functie)  ON UPDATE CASCADE ON DELETE CASCADE
);

create table Impozite 
(
ID_impozit int IDENTITY(1,1) primary key,
nume varchar(50),
valoare int 
);

create table Contracte
(
ID_contract int IDENTITY(1,1) primary key,
ID_angajat int,
constraint FK_ID_angajat foreign key(ID_angajat) references Staff(ID_staff)  ON UPDATE CASCADE ON DELETE CASCADE,
descriere varchar(50)
);

create table ContracteImpozite
(
	ID_contract int,
	ID_impozit int
	constraint FK_ID_contract foreign key(ID_contract) references Contracte(ID_contract)  ON UPDATE CASCADE ON DELETE CASCADE,
	constraint FK_ID_impozit foreign key(ID_impozit) references Impozite(ID_impozit)  ON UPDATE CASCADE ON DELETE CASCADE,
);

alter table ContracteImpozite
add  ID int IDENTITY(1,1) primary key








IF OBJECT_ID ('tr_salariu_brut_minim', 'TR') IS NOT NULL
	DROP TRIGGER tr_salariu_brut_minim;
	
GO
CREATE TRIGGER tr_salariu_brut_minim
ON Functii
FOR INSERT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM inserted WHERE salariu_brut < 2500)
    BEGIN
        RAISERROR ('Salariul brut trebuie să fie mai mare de 2500!', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;

INSERT INTO Functii(ID_departament, nume, salariu_brut) VALUES (13, 'Controlor acte', 2000)

SELECT*
FROM Departamente
	
	IF OBJECT_ID ('trig_locatie_tara', 'TR') IS NOT NULL
	DROP TRIGGER trig_locatie_tara;

	go
	CREATE TRIGGER trig_locatie_tara
	ON Locatii
	FOR INSERT
	AS
	BEGIN
	IF NOT EXISTS(SELECT * FROM inserted WHERE ID_tara IS NOT NULL)
	BEGIN
	RAISERROR('Nu s-a specificat tara pentru aceasta locatie!', 16, 1)
	ROLLBACK TRANSACTION
	END
END
insert into Locatii(nume_locatie) values ('Cluj')






	--Trigger pentru tabelul "Calatori" care s? verifice dac? CNP-ul introdus sau actualizat este valid (format din 13 cifre).
	IF OBJECT_ID ('tr_check_cnp', 'TR') IS NOT NULL
	DROP TRIGGER tr_check_cnp;

		go
		CREATE TRIGGER tr_check_cnp
	ON Calatori
	FOR INSERT, UPDATE
	AS
	BEGIN
		IF EXISTS(SELECT * FROM inserted WHERE LEN(CNP) != 13 )
		BEGIN
			RAISERROR('CNP-ul introdus trebuie sa contina 13 cifre!', 16, 1)
			ROLLBACK
		END
	END;


	 

	---Trigger to prevent insertion of a duplicate value in the 'nume_tara' column of the 'Tari' table:
		IF OBJECT_ID ('trg_Tari_duplicate', 'TR') IS NOT NULL
		DROP TRIGGER trg_Tari_duplicate;

			go
			CREATE TRIGGER trg_Tari_duplicate
		ON Tari
		AFTER INSERT
		AS
		BEGIN
		  IF EXISTS (SELECT 1 FROM Tari GROUP BY nume_tara HAVING COUNT(*) > 1)
		  BEGIN
			RAISERROR('Cannot insert duplicate values in the nume_tara column of the Tari table.', 16, 1)
			ROLLBACK TRANSACTION
		  END
		END
	
	insert into Tari (nume_tara) values ('Italia')
	insert into Tari (nume_tara) values ('Italia')


	---Trigger pentru actualizarea pretului biletelor
	IF OBJECT_ID ('trig_update_pret_bilete', 'TR') IS NOT NULL
    DROP TRIGGER trig_update_pret_bilete;
		go
		CREATE TRIGGER trig_update_pret_bilete
	ON Bilete
	AFTER UPDATE
	AS
	BEGIN
		UPDATE Bilete
		SET pret_bilet = i.pret_bilet
		FROM Bilete b
		INNER JOIN inserted i ON b.ID_bilet = i.ID_bilet
		WHERE b.pret_bilet < i.pret_bilet
	END;

	insert Bilete (pret_bilet) values (1000);

	update Bilete 
	SET pret_bilet = 10
	where pret_bilet = 1000
		select*
		from Bilete
	

	INSERT INTO Companii (nume_companie) VALUES ('AirlineX');
	INSERT INTO Companii (nume_companie) VALUES ('BlueAir');
	insert into Companii (nume_companie) values ('WizzAir');
	

	insert into Zboruri (ID_companie) values ('3');
	DELETE FROM Companii WHERE ID_companie = 3;

	select *
	from Zboruri


	---trigger care s? nu permit? inserarea unui num?r de telefon cu mai mult de 10 cifre în tabela "Calatori"
	
	IF OBJECT_ID ('tr_check_telefon', 'TR') IS NOT NULL
    DROP TRIGGER tr_check_telefon;
	go
		CREATE TRIGGER tr_check_telefon
	ON Calatori
	FOR INSERT, UPDATE
	AS
	BEGIN
		IF EXISTS(SELECT * FROM inserted WHERE LEN(CNP) != 10 )
		BEGIN
			RAISERROR('Numarul de telefon introdus trebuie sa contina 10 cifre!', 16, 1)
			ROLLBACK
		END
	END;

	
	insert Calatori (CNP, nume, prenume,  telefon, email, adresa) values ('1234567800101','Radu', 'Marin', '123' ,'marin@gmail.com', 'Constanta')
	update Calatori
	set telefon = '123'

	-- trigger care s? previn? inserarea unei date de plecare mai mici decât data actual? în tabelul "Zboruri"

	IF OBJECT_ID ('trigger_data_plecare', 'TR') IS NOT NULL
    DROP TRIGGER trigger_data_plecare;

			go
			CREATE TRIGGER trigger_data_plecare ON Zboruri
		FOR INSERT, UPDATE
		AS
		BEGIN
		IF EXISTS (SELECT * FROM inserted WHERE data_plecare < GETDATE())
		BEGIN
		RAISERROR ('Data plecarii nu poate fi mai mica decat data actuala.', 16, 1)
		ROLLBACK TRANSACTION
		END
		END;

		insert into Zboruri (data_plecare) values ('1993-06-23')
		
		----feminin masculin
		go
	CREATE TRIGGER insert_calator
	ON Calatori
	FOR INSERT
	AS
	BEGIN
	DECLARE @sex varchar(10)
	SELECT @sex = sex FROM inserted
	IF (@sex <> 'FEMININ' AND @sex <> 'MASCULIN')
	BEGIN
	RAISERROR('Sexul trebuie sa fie FEMININ sau MASCULIN!', 16, 1)
	ROLLBACK TRANSACTION
	END
	END

	insert into Calatori (nume, prenume, sex) values ('Ana', 'Maria', 'h')
	
	----Trigger pentru a preveni adaugarea unei locatii fara a specifica tara

	go
	CREATE TRIGGER trig_locatie_tara
	ON Locatii
	FOR INSERT
	AS
	BEGIN
	IF NOT EXISTS(SELECT * FROM inserted WHERE ID_tara IS NOT NULL)
	BEGIN
	RAISERROR('Nu s-a specificat tara pentru aceasta locatie!', 16, 1)
	ROLLBACK TRANSACTION
	END
	END

insert into Locatii(nume_locatie) values ('Cluj') 

go
CREATE TRIGGER trig_gates_numar
ON Gates
FOR INSERT
AS
BEGIN
IF NOT EXISTS(SELECT * FROM inserted WHERE numar IS NOT NULL)
BEGIN
RAISERROR('Nu s-a specificat numarul pentru aceasta poarta!', 16, 1)
ROLLBACK TRANSACTION
END
END


alter table Gates
add capacitate int

select*
from Gates

insert into Gates(capacitate) values(60)

---introducere telefon
go
CREATE TRIGGER trig_staff_telefon
ON Staff
FOR INSERT
AS
BEGIN
IF NOT EXISTS(SELECT * FROM inserted WHERE telefon IS NOT NULL)
BEGIN
RAISERROR('Nu s-a specificat telefonul pentru acest staff!', 16, 1)
ROLLBACK TRANSACTION
END
END

insert into Staff(nume,prenume, email) values('Mariuc','Andrei', 'AndreiMa@email.com')

---adaugare task cand se adauga zbor
go
CREATE TRIGGER trg_InsertTaskOnNewFlight
ON Zboruri
AFTER INSERT
AS
BEGIN
    DECLARE @ID_zbor int;
    SELECT @ID_zbor = ID_zbor FROM inserted;
    INSERT INTO Tasks (nume, ID_zbor) VALUES ('Verificare zbor', @ID_zbor);
END

insert Zboruri(data_plecare) values('2024-04-07')
select *
from Tasks



go
CREATE TRIGGER trg_InsertFunctionAssignmentOnNewEmployee
ON Functii
AFTER INSERT
AS
BEGIN
    DECLARE @ID_staff int, @ID_functie int;
    SELECT  @ID_functie = ID_functie FROM inserted;
    INSERT INTO Repartizare_functii (ID_staff, ID_functie) VALUES (@ID_staff, @ID_functie);
END

insert into Staff(nume, prenume, telefon, email, departament) values('Daniliuc', 'Constantin','07363767449' ,'constantin@gmail.com', 'Verificare')
select*
from Repartizare_functii
SELECT*
FROM FUNCTII

insert into Functii(nume) values ('Control BAGAJE')
go
CREATE TRIGGER tr_companii_duplicate_name
ON Companii
FOR INSERT, UPDATE
AS
BEGIN
    IF EXISTS(
        SELECT 1
        FROM inserted i
        JOIN Companii c ON i.nume_companie = c.nume_companie AND i.ID_companie != c.ID_companie
    )
    BEGIN
        RAISERROR('Nu pot fi inserate doua companii cu acelasi nume!', 16, 1);
        ROLLBACK;
    END
END;
insert into Companii(nume_companie) values('FranceAirline')
insert into Companii(nume_companie) values('FranceAirline')
----------------------------------------------------------------------

---Procedura pentru inserarea unui nou avion în baza de date
go
CREATE PROCEDURE dbo.InsertAvion
@ID_companie int,
@model varchar(20),
@capacitate int
AS
BEGIN
INSERT INTO Avioane (ID_companie, model, capacitate)
VALUES (@ID_companie, @model, @capacitate)
END

---Procedura pentru inserarea unei noi companii în baza de date

IF OBJECT_ID ('dbo.InsertCompanie', 'P') IS NOT NULL
DROP PROC dbo.InsertCompanie;

go
CREATE PROCEDURE dbo.InsertCompanie
@nume_companie varchar(20)
AS
BEGIN
INSERT INTO Companii (nume_companie)
VALUES (@nume_companie)
END

EXEC dbo.InsertCompanie 'AirBoom';
EXEC dbo.InsertCompanie 'AirBloom';

select*
from Companii

IF OBJECT_ID ('dbo.AddCalator', 'P') IS NOT NULL
DROP PROC dbo.AddCalator;

go
CREATE PROCEDURE dbo.AddCalator
    @CNP varchar(13),
    @nume varchar(20),
    @prenume varchar(20),
    @sex varchar(10),
    @email varchar(20),
    @telefon varchar(15),
    @adresa varchar(30)
AS
BEGIN
    INSERT INTO Calatori(CNP, nume, prenume, sex, email, telefon, adresa)
    VALUES (@CNP, @nume, @prenume, @sex, @email, @telefon, @adresa);
END

EXEC dbo.AddCalator 
    @CNP = '1234567870123',
    @nume = 'Popescu',
    @prenume = 'Ion',
    @sex = 'MASCULIN',
    @email = 'popescu.ion@gmail.com',
    @telefon = '0780658251',
    @adresa = 'Str. Exemplu, Nr. 10';


IF OBJECT_ID ('dbo.AddAeroport', 'P') IS NOT NULL
DROP PROC dbo.AddAeroport;

	go
	CREATE PROCEDURE dbo.AddAeroport
    @nume varchar(50),
    @ID_oras int
AS
BEGIN
    INSERT INTO Aeroporturi(nume, ID_oras)
    VALUES (@nume, @ID_oras);
END

exec dbo.AddAeroport 
	@nume = 'Charles du Gaulle',
    @ID_oras = 3
	
	select*
	from Aeroporturi

IF OBJECT_ID ('dbo.AddLocatie', 'P') IS NOT NULL
DROP PROC dbo.AddLocatie;

	go
	CREATE PROCEDURE dbo.AddLocatie
    @ID_tara int,
    @nume_locatie varchar(20)
AS
BEGIN
    INSERT INTO Locatii(ID_tara, nume_locatie)
    VALUES (@ID_tara, @nume_locatie);
END

select*
from Tari

exec dbo.AddLocatie 
	@ID_tara = 1,
    @nume_locatie = 'Venezia'

	select*
	from Locatii

	IF OBJECT_ID('CatchError', 'P') IS NOT NULL
DROP PROC CatchError;
GO
CREATE PROC CatchError
@errorCode AS INT
AS
BEGIN
IF @errorCode <> 0
BEGIN
IF @@TRANCOUNT > 0 ROLLBACK TRAN;
PRINT 'Transaction failed with error code '+ CAST(@errorCode AS VARCHAR);
RETURN;
END;
END;

IF OBJECT_ID ('dbo.CountTaskEmployees', 'P') IS NOT NULL
DROP PROC dbo.CountTaskEmployees;

go
CREATE PROCEDURE dbo.CountTaskEmployees
  @TaskName VARCHAR(50)
AS
BEGIN
  SELECT COUNT(*) AS NumEmployees
  FROM StaffTasks st
  INNER JOIN Tasks t ON t.ID_task = st.ID_task
  WHERE t.nume = @TaskName;
END;

select*
from Tasks
select*
from Staff

EXEC dbo.CountTaskEmployees @TaskName = 'Verificare zbor'

IF OBJECT_ID ('NumarBileteVandute', 'P') IS NOT NULL
DROP PROC NumarBileteVandute;


go
CREATE PROCEDURE NumarBileteVandute
AS
BEGIN
    SELECT Z.ID_zbor, COUNT(*) AS NumarBileteVandute
    FROM Zboruri Z
    INNER JOIN BiletePerZbor B
    ON Z.ID_zbor = B.id_zbor
    GROUP BY Z.ID_zbor
END


IF OBJECT_ID('sp_NumarGatesDisponibile', 'P') IS NOT NULL
DROP PROC sp_NumarGatesDisponibile;
go
CREATE PROCEDURE sp_NumarGatesDisponibile @ID_Zbor int
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @NrGates INT;
    
    SELECT @NrGates = COUNT(*) FROM Gates WHERE ID_gate NOT IN 
        (SELECT ID_gate FROM ZboruriGates WHERE ID_zbor = @ID_Zbor);
    
    SELECT @NrGates AS NumarGatesDisponibile;
END

select*
from Zboruri

EXEC sp_NumarGatesDisponibile @ID_Zbor = 3;

IF OBJECT_ID('CalculNumarAngajati', 'P') IS NOT NULL
DROP PROC CalculNumarAngajati;

go
CREATE PROCEDURE dbo.CalculNumarAngajati
AS
BEGIN
    SELECT COUNT(*) AS 'NumarAngajati'
    FROM Staff
END

select*
from Staff

EXEC dbo.CalculNumarAngajati

IF OBJECT_ID('CalculeazaSumaVanzariBilete', 'P') IS NOT NULL
DROP PROC CalculeazaSumaVanzariBilete;


go
CREATE PROCEDURE CalculeazaSumaVanzariBilete
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @suma int;
  SELECT @suma = SUM(b.pret_bilet)
  FROM BiletePerZbor bpz
  INNER JOIN Bilete b ON bpz.id_bilet = b.ID_bilet;
  PRINT 'Suma totala din urma vanzarii biletelor este ' + CAST(@suma AS VARCHAR(20));
END

select*
from BiletePerZbor

select*
from Bilete


IF OBJECT_ID('CountFlights', 'P') IS NOT NULL
DROP PROC CountFlights;


go
CREATE PROCEDURE CountFlights
AS
BEGIN
    SELECT COUNT(*) AS TotalFlights
    FROM Zboruri;
END

select*
from Zboruri
EXEC CountFlights;


IF OBJECT_ID('CommitTransction', 'P') IS NOT NULL
DROP PROC CommitTransction;
GO
CREATE PROC CommitTransction
AS
BEGIN
IF @@TRANCOUNT > 0 
BEGIN
COMMIT TRAN;
PRINT 'Transaction successfully commited';
END;
END;

---------------------------------------------TRANZACTII

select*
from Avioane
--Adaugarea unui nou avion:
BEGIN TRY
BEGIN TRAN
INSERT INTO Avioane (ID_avion, ID_companie, model, capacitate)
VALUES (14, 1, 'Boeing 739', 150);
COMMIT TRAN
END TRY
begin catch
if ERROR_NUMBER() = 2627 --error for duplicate key violation
begin
print 'Primary key violation';
end
else if ERROR_NUMBER() = 547 --constraint violations
begin
print 'Constraint violation';
end
else
begin
print 'Unhandled error';
end
if @@TRANCOUNT > 0
rollback tran
end catch

select*
from Avioane

---Modificarea unei companii aeriene:
BEGIN TRY
BEGIN TRAN
UPDATE Companii
SET nume_companie = 'Air Aeroflot'
WHERE ID_companie = 21;
COMMIT TRAN
END TRY
begin catch
if ERROR_NUMBER() = 2627 --error for duplicate key violation
begin
print 'Primary key violation';
end
else if ERROR_NUMBER() = 547 --constraint violations
begin
print 'Constraint violation';
end
else
begin
print 'Unhandled error';
end
if @@TRANCOUNT > 0
rollback tran
end catch

select*
from Companii
----Stergerea unei tari si a tuturor locatiilor aferente:

insert into Tari(nume_tara) values ('Franta')

BEGIN TRAN
DELETE FROM Tari
WHERE ID_tara = 3;
COMMIT

select*
from Tari

---Adaugarea unui nou gate:
BEGIN TRAN
INSERT INTO Gates (numar)
VALUES (12);
COMMIT

select*
from Gates

----Adaugarea unei noi sarcini pentru un zbor:
BEGIN TRAN
INSERT INTO Tasks(nume, ID_zbor)
VALUES ('Verificare securitate', 2);
COMMIT

--Adaugarea unui nou calator:
BEGIN TRAN
INSERT INTO Calatori (CNP, nume, prenume, sex, email, telefon, adresa)
VALUES ('1234567890123', 'Popescu', 'Ana', 'FEMININ', 'ana.popescu@gmail.com', '0745123456', 'Bucuresti');
COMMIT

--Modificarea unei clase:
BEGIN TRAN
UPDATE Clasa
SET NUME_CLASA = 'PREMIUM ECONOMIC'
WHERE ID_clasa = 1;
COMMIT

--Stergerea unui aeroport si a tuturor zborurilor aferente:
BEGIN TRAN
DELETE FROM Aeroporturi
WHERE ID_aeroport = 4;
COMMIT

--Adaugarea unui nou gate:
BEGIN TRAN
INSERT INTO Gates (numar)
VALUES (12);
COMMIT

--Modificarea unei zboruri:

BEGIN TRAN
UPDATE Zboruri
SET ora = '10:30', data_plecare = '2023-05-15', durata = 120
WHERE ID_zbor = 3;
COMMIT

--Stergerea unui bilet si a tuturor biletelor aferente unui zbor:
BEGIN TRAN
DELETE FROM BiletePerZbor
WHERE id_zbor = 2;
DELETE FROM Bilet
WHERE ID_bilet = 5;
COMMIT


BEGIN TRANSACTION

-- Tranzacție 1
SAVE TRANSACTION Tr1;

BEGIN TRY
    -- Inserare în tabelul Tari
    INSERT INTO Tari (nume_tara) VALUES ('Romania');

    -- Tranzacție 2
    SAVE TRANSACTION Tr2;

    BEGIN TRY
        -- Inserare în tabelul Locatii
        DECLARE @ID_tara INT;
        SELECT @ID_tara = ID_tara FROM Tari WHERE nume_tara = 'Romania';

        INSERT INTO Locatii (ID_tara, nume_locatie) VALUES (@ID_tara, 'Bucuresti');

        -- Tranzacție 3
        SAVE TRANSACTION Tr3;

        BEGIN TRY
            -- Inserare în tabelul Aeroporturi
            DECLARE @ID_locatie INT;
            SELECT @ID_locatie = ID_locatie FROM Locatii WHERE nume_locatie = 'Bucuresti';

            INSERT INTO Aeroporturi (nume, ID_oras) VALUES ('Aeroportul Otopeni', @ID_locatie);

            -- Tranzacție 4
            SAVE TRANSACTION Tr4;

            BEGIN TRY
                -- Inserare în tabelul Companii
                INSERT INTO Companii (nume_companie) VALUES ('Tarom');

                -- Tranzacție 5
                SAVE TRANSACTION Tr5;

                BEGIN TRY
                    -- Inserare în tabelul Avioane
                    DECLARE @ID_companie INT;
                    SELECT @ID_companie = ID_companie FROM Companii WHERE nume_companie = 'Tarom';

                    INSERT INTO Avioane (ID_avion, model, capacitate, ID_companie) VALUES (1, 'Airbus A320', 180, @ID_companie);

                    -- Restul acțiunilor tranzacției 5

                    COMMIT TRANSACTION Tr5;
                END TRY
                BEGIN CATCH
                    -- Tranzacție 5 a eșuat, anulăm până la Tr4
                    ROLLBACK TRANSACTION Tr4;
                    PRINT 'Eroare la tranzacția 5';
                END CATCH;

                -- Restul acțiunilor tranzacției 4

                COMMIT TRANSACTION Tr4;
            END TRY
            BEGIN CATCH
                -- Tranzacție 4 a eșuat, anulăm până la Tr3
                ROLLBACK TRANSACTION Tr3;
                PRINT 'Eroare la tranzacția 4';
            END CATCH;

            -- Restul acțiunilor tranzacției 3

            COMMIT TRANSACTION Tr3;
        END TRY
        BEGIN CATCH
            -- Tranzacție 3 a eșuat, anulăm până la Tr2
            ROLLBACK TRANSACTION Tr2;
            PRINT 'Eroare la tranzacția 3';
        END CATCH;

        -- Restul acțiunilor tranzacției 2

        COMMIT TRANSACTION Tr2;
    END TRY
    BEGIN CATCH
        -- Tranzacție 2 a eșuat, anulăm până la Tr1
        ROLLBACK TRANSACTION Tr1;
        PRINT 'Eroare la tranzacția 2'
    END CATCH
COMMIT TRANSACTION Tr1;
END TRY
BEGIN CATCH
-- Tranzacția 1 a eșuat, anulăm tranzacția principală
ROLLBACK TRANSACTION;
PRINT 'Eroare la tranzacția 1';
END CATCH;

-- Restul acțiunilor din afara tranzacțiilor imbricate

COMMIT TRANSACTION;

--Adaugarea unei noi sarcini pentru un zbor:
BEGIN TRAN
INSERT INTO Tasks (nume, ID_zbor)
VALUES ('Verificare securitate', 2);
COMMIT

insert into Tari values('Romania')
select*
from Tari


BEGIN TRANSACTION;

BEGIN TRY
    SAVE TRANSACTION Tr3;

    -- Acțiunile din tranzacția 3
    -- Exemplu: Inserarea datelor în tabelele Tari, Locatii și Aeroporturi

    -- Inserarea unei noi țări
    INSERT INTO Tari (nume_tara) VALUES ('Grecia');

    -- Obținerea ID-ului țării inserate
    DECLARE @ID_t INT;
    SET @ID_t = SCOPE_IDENTITY();

    -- Inserarea unei noi locații
    INSERT INTO Locatii (ID_tara, nume_locatie) VALUES (@ID_t, 'Atena');

    -- Obținerea ID-ului locației inserate
    DECLARE @ID_l INT;
    SET @ID_l = SCOPE_IDENTITY();

    -- Inserarea unui nou aeroport
    INSERT INTO Aeroporturi (nume, ID_oras) VALUES ('Aeroportul Eleftherios', @ID_l);

    COMMIT TRANSACTION Tr3;
END TRY
BEGIN CATCH
    -- Tranzacția 3 a eșuat, anulăm tranzacția principală
    ROLLBACK TRANSACTION;
    THROW;
END CATCH;

COMMIT TRANSACTION;


--Tranzactie pentru adaugarea unei locatii in tabela Locatii, cu referinta la o tara existenta:
BEGIN TRANSACTION
DECLARE @ID_tara INT
SELECT @ID_tara = ID_tara FROM Tari WHERE nume_tara = 'Romania'
INSERT INTO Locatii (ID_tara, nume_locatie) VALUES (@ID_tara, 'Bucuresti')
COMMIT

select*
from Locatii


--Tranzactie pentru adaugarea unui aeroport in tabela Aeroporturi, cu referinta la o locatie existenta:
BEGIN TRANSACTION
DECLARE @ID_locatie INT
SELECT @ID_locatie = ID_locatie FROM Locatii WHERE nume_locatie = 'Bucuresti'
INSERT INTO Aeroporturi (nume, ID_oras) VALUES ('Aeroportul Henri Coanda', @ID_locatie)
COMMIT


BEGIN TRANSACTION;

BEGIN TRY
    -- Tranzacția principală

    -- Acțiunile din tranzacția principală
    -- Exemplu: Actualizarea unei locații și ștergerea unui aeroport

    -- Actualizarea unei locații existente
    UPDATE Locatii
    SET nume_locatie = 'Cluj-Napoca'
    WHERE ID_locatie = 2;

    -- Salvarea punctului de salvare pentru tranzacția imbricată
    SAVE TRANSACTION Tr4;

    -- Tranzacția imbricată

    BEGIN TRY
        -- Acțiunile din tranzacția imbricată
        -- Exemplu: Inserarea unei noi companii și a unui nou avion

        -- Inserarea unei noi companii
        INSERT INTO Companii (nume_companie) VALUES ('Blue Air');

        -- Obținerea ID-ului companiei inserate
        DECLARE @ID_c INT;
        SET @ID_c = SCOPE_IDENTITY();

        -- Inserarea unui nou avion pentru compania respectivă
        INSERT INTO Avioane (ID_avion, model, capacitate, ID_companie)
        VALUES (14, 'Airbus A320', 180, @ID_c);

        -- Confirmarea tranzacției imbricate
        COMMIT TRANSACTION Tr4;
    END TRY
    BEGIN CATCH
        -- Tranzacția imbricată a eșuat, anulăm tranzacția principală
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH;

    -- Continuarea acțiunilor din tranzacția principală
    -- Exemplu: Ștergerea unui aeroport

    -- Ștergerea unui aeroport existent
    DELETE FROM Aeroporturi
    WHERE ID_aeroport = 3;

    -- Confirmarea tranzacției principală
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
BEGIN TRANSACTION
    -- Tranzacția principală a eșuat
    ROLLBACK TRANSACTION;
    THROW;
END CATCH;



select*
from Aeroporturi

---
BEGIN TRANSACTION
DECLARE @ID_avion INT, @ID_aeroport INT
SELECT @ID_avion = ID_avion FROM Avioane WHERE model = 'Boeing 737'
SELECT @ID_aeroport = ID_aeroport FROM Aeroporturi WHERE nume = 'Aeroportul Henri Coanda'
INSERT INTO Zboruri (ID_avion, ora, data_plecare, durata, ID_aeroport) VALUES ( @ID_avion, '10:00:00', '2023-05-01', 3, @ID_aeroport)

select*
from Zboruri

delete 
from Zboruri
where ID_zbor = 7

insert into Aeroporturi(nume) values('Tarom')

select*
from Aeroporturi


--Actualizarea salariului brut pentru functia de Manager din tabela Functii:
BEGIN TRANSACTION
UPDATE Functii SET salariu_brut = 12000 WHERE nume = 'Manager';
COMMIT;

----Adaugarea unei functii noi in tabela Functii:
BEGIN TRANSACTION
INSERT INTO Functii (nume, salariu_brut) VALUES ('Manager', 10000);

EXEC CatchError @errorCode = @@ERROR;
EXEC CommitTransction;


----Adăugarea unui nou staff la baza de date:
BEGIN TRAN

INSERT INTO Staff(nume, prenume, email, telefon)
VALUES ('Popescu', 'Ana', 'ana.popescu@gmail.com', '0721123456');

DECLARE @id_staff INT
SET @id_staff = @@IDENTITY

INSERT INTO Repartizare_functii(ID_staff, ID_functie)
VALUES (@id_staff, 2);

COMMIT TRAN
select*
from Staff

--Achiziționarea unui bilet de avion:

BEGIN TRAN

DECLARE @pret_bilet INT
SET @pret_bilet = 250

INSERT INTO Bilete(ID_calator, ID_clasa, pret_bilet)
VALUES (3, 1, @pret_bilet);

DECLARE @id_bilet INT
SET @id_bilet = @@IDENTITY

INSERT INTO BiletePerZbor(id_bilet, id_zbor)
VALUES (@id_bilet, 4);

COMMIT TRAN

select*
from Calatori

select*
from Clase

insert into Clase(NUME_CLASA) values ('Economic')

select*
from Zboruri


BEGIN TRANSACTION;
INSERT INTO Tari (nume_tara) VALUES ('Albania');
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRANSACTION;
END
ELSE
BEGIN
    COMMIT TRANSACTION;
END

select*
from Tari

BEGIN TRANSACTION;
INSERT INTO Zboruri (ID_companie, ID_avion, ora, data_plecare, durata, ID_aeroport) VALUES (6, 1, '14:30:00', '2023-05-01', 120, 1);
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRANSACTION;
END
ELSE
BEGIN
    COMMIT TRANSACTION;
END

select*
from Avioane


BEGIN TRANSACTION;
INSERT INTO Locatii (ID_tara, nume_locatie) VALUES (1, 'Bucuresti');
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRANSACTION;
END
ELSE
BEGIN
    COMMIT TRANSACTION;
END

BEGIN TRANSACTION;
INSERT INTO Companii (nume_companie) VALUES ('Blue Air');
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRANSACTION;
END
ELSE
BEGIN
    COMMIT TRANSACTION;
END

BEGIN TRANSACTION;
INSERT INTO Clase(NUME_CLASA) VALUES ('ECONOMIC');
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRANSACTION;
END
ELSE
BEGIN
    COMMIT TRANSACTION;
END


---Ștergerea unei funcții din baza de date:

BEGIN TRANSACTION
DELETE FROM Functii WHERE ID_functie = 2
ROLLBACK


---Actualizarea unui zbor:

BEGIN TRANSACTION
UPDATE Zboruri SET ID_companie = 2, ID_avion = 3 WHERE ID_zbor = 1
ROLLBACK

BEGIN TRANSACTION
UPDATE Calatori SET nume = 'Popescu', prenume = 'Andrei', sex = 'MASCULIN', email = 'popescu.andrei@gmail.com' WHERE ID_calator = 1
ROLLBACK

BEGIN TRANSACTION;
INSERT INTO Calatori (CNP, nume, prenume, sex, email, telefon, adresa) VALUES ('1234567890123', 'Popescu', 'Ion', 'MASCULIN', 'popescu.ion@example.com', '0722333444', 'Str. Victoriei, Nr. 1');
INSERT INTO Calatori (CNP, nume, prenume, sex, email, telefon, adresa) VALUES ('2345678901234', 'Ionescu', 'Maria', 'FEMININ', 'ionescu.maria@example.com', '0722444555', 'Str. Libertatii, Nr. 2');
COMMIT;


select*
from Tari

INSERT INTO Tari (nume_tara) VALUES
('Romania'),
('SUA'),
('Spain'),
('Marea Britanie'),
('Germania'),
('Japonia'),
('China'),
('Rusia');

select*
from Locatii

INSERT INTO Locatii (ID_tara, nume_locatie) VALUES
(7, 'Bucuresti'),
(8, 'New York'),
(1, 'Roma'),
(9, 'Barcelona'),
(10, 'Londra'),
(11, 'Berlin'),
(12, 'Tokyo'),
(13, 'Beijing'),
(14, 'Moscova');

select*
from Companii

INSERT INTO Companii (nume_companie) VALUES
('Blue Air'),
('American Airlines'),
('Air France'),
('Alitalia'),
('Iberia'),
('British Airways'),
('Lufthansa'),
('ANA'),
('Air China'),
('Aeroflot');

select*
from Calatori

delete
from Calatori

drop trigger trig_stergere_calator

INSERT INTO Calatori (CNP, nume, prenume, sex, email, telefon, adresa) VALUES
('1234567890123', 'Popescu', 'Ion', 'MASCULIN', 'popescui@gmail.com', '0766123456', 'Str.Libertatii, 10, Bucuresti'),
('2345678901234', 'Ionescu', 'Maria', 'FEMININ', 'ionescum@yahoo.com', '0721123456', 'Str.Victoriei, 5, Timisoara'),
('3456789012345', 'Popa', 'Alexandru', 'MASCULIN', 'popaa@gmail.com', '0732123456', 'Str.Mihai Eminescu, 20, Brasov'),
('4567890123456', 'Georgescu', 'Andreea', 'FEMININ', 'georgescua@yahoo.com', '0743123456', 'Str.Unirii, 15, Iasi'),
('5678901234567', 'Popovici', 'Mihai', 'MASCULIN', 'popovicim@gmail.com', '0754123456', 'Str.Aviatorilor, 11, Cluj'),
('6789012345678', 'Iacob', 'Gabriela', 'FEMININ', 'iacobg@hotmail.com', '0765123456', 'Str.Vlaicu, 22, Constanta'),
('7890123456789', 'Dumitrescu', 'Daniel', 'MASCULIN', 'dumitrescu@yahoo.com', '0776123456', 'Str.Timotei, 3, Suceava'); 

drop trigger tr_check_telefon



INSERT INTO Aeroporturi (nume, ID_oras) VALUES 
('Charles de Gaulle', 3),
('Marco Polo', 5),
('Henri Coanda', 13),
('JFK', 14),
('Fiumicino', 15),
('El Prat', 16),
('Heathrow', 17),
('Tegel', 18),
('Narita', 19),
 ('Beijing Capital', 20);

 select*
from Locatii

select*
from Aeroporturi

INSERT INTO Gates (numar, capacitate) VALUES 
(1,100),(2,110),(3,120),(4,130),(5,140),(6,150),(7,160),(8,170),(9,180),(10,190);

select*
from Calatori


INSERT INTO Clase (NUME_CLASA) VALUES ('ECONOMIC');
INSERT INTO Clase (NUME_CLASA) VALUES ('BUSINESS');

INSERT INTO Calatori (CNP, nume, prenume, sex, email, telefon, adresa) VALUES 
('1234567890123', 'Popescu', 'Ana', 'FEMININ', 'ana.p@gmail.com', '0721123456', 'Str. Libertatii nr. 10'),
('1234567890124', 'Ionescu', 'Alex', 'MASCULIN', 'alex.i@gmail.com', '0723123456', 'Str. Independentei nr. 20'),
('1234567890125', 'Popa', 'Maria', 'FEMININ', 'maria.p@gmail.com', '0731123456', 'Str. Unirii nr. 15'),
('1234567890126', 'Vasilescu', 'Alexandra', 'FEMININ', 'alex.v@gmail.com', '0741123456', 'Str. Mihai Viteazul nr. 5'),
('1234567890127', 'Popescu', 'Mihai', 'MASCULIN', 'mihai.p@gmail.com', '0726123456', 'Str. Republicii nr. 7'),
('1234567890128', 'Dumitru', 'Diana', 'FEMININ', 'diana.d@gmail.com', '0751123456', 'Str. Ion Creanga nr. 12'),
('1234567890129', 'Radulescu', 'Andrei', 'MASCULIN', 'andrei.r@gmail.com', '0729123456', 'Str. Gheorghe Doja nr. 14'),
('1234567890130', 'Georgescu', 'Elena', 'FEMININ', 'elena.g@gmail.com', '0742123456', 'Str. Tudor Vladimirescu nr. 17'),
('1234567890131', 'Petrescu', 'Marian', 'MASCULIN', 'marian.p@gmail.com', '0732123456', 'Str. Vasile Alecsandri nr. 19'),
('1234567890132', 'Stefanescu', 'Alina', 'FEMININ', 'alina.s@gmail.com', '0761123456', 'Str. Stefan cel Mare nr. 9');

INSERT INTO Bilete(ID_calator, ID_clasa, pret_bilet) VALUES
(66,3,100),
(67,4,2000),
(68,3,200),
(69,4,2000),
(70,3,300),
(71,3,200),
(72,4,2000),
(73,3,300),
(74,3,400),
(75,4,2200);

select*
from Bilete



select*
from Calatori

INSERT INTO Departamente (denumire, utilitate) VALUES 
('Tehnologia informatiei', 'Se ocupa cu administrarea sistemelor informatice'),
('Siguranta', 'Verificarea pasagerilor si a bagajelor'),
('Operatiuni aeroportuare', 'Asigura pregatirea si gestionarea operatiunilor'),
('Informatii pasageri', 'Asigura furnizarea de informatii catre pasageri'),
('Mentenanta', 'Asigura intretinerea si repararea echipamentelor'),
('Aprovizionare', 'Aprovizionarea aeroportului cu diverse resurse'),
('Financiar-contabil', 'Se ocupa cu administrarea resurselor financiare'),
('Marketing', 'Promovarea serviciilor aeroportuare'),
('Resurse umane', 'Gestionarea resurselor umane ale aeroportului'),
('Planificare si dezvoltare', 'Se ocupa cu planificarea infrastructurii');

select*
from Functii

INSERT INTO Functii (nume, salariu_brut, ID_departament) VALUES
('Manager', 10000, 19),
('Programator', 5000, 10),
('Contabil', 8000, 16),
('Tehnician', 4000, 14),
('Supraveghetor trafic aerian', 4500, 12),
('Responsabil mentenanta', 4200, 14),
('Casier', 2700, 16),
('Agent de securitate', 3000, 11),
('Inginer aprovizionare', 5500, 15),
('Manager marketing', 6000, 17),
('Manager resurse umane', 5500, 18);


select*
from Avioane

delete 
from Avioane

INSERT INTO Avioane (ID_Companie, model, capacitate, ID_avion)
VALUES (12, 'Boeing 747', 416, 1),
	   (13, 'Airbus A380', 853, 2),
	   (14, 'Boeing 737', 215, 3),
	   (15, 'Airbus A320', 180, 4),
	   (16, 'Boeing 777', 396, 5),
	   (17, 'Airbus A330', 335, 6),
	   (18, 'Embraer E190', 100, 7),
	   (19, 'Bombardier CRJ700', 78, 8),
	   (20, 'ATR 72', 74, 9),
	   (21, 'Sukhoi Superjet 100', 103, 10);

	   select*
	   from Companii

	   alter table Impozite
	   alter column nume varchar(70)

	     alter table Impozite
		alter column valoare real

		delete
		from Impozite

	   INSERT INTO Impozite (nume, valoare) VALUES 
	   ('Impozit pe venitul salarial', 10), -- Impozitul pe venitul salarial
	   ('Contributie la CASS', 5), -- Contribuția la sistemul de asigurări sociale de sănătate (CASS)
	   ('Contributie la CAS', 25),  -- Contribuția la sistemul de asigurări sociale (CAS)
	   ('Contributie la Fondul de somaj', 2),  -- Contribuția la Fondul de șomaj
	   ('Contributia la Fondul de garantare pentru plata creantelor salariale', 1),
	   ('Contributia la Fondul pentru pensii administrate privat (Pilonul II)', 3),
	   ('Contributia la Fondul de risc si accidente de munca - clasa de risc I', 0.2),
		('Contributia la Fondul de risc si accidente de munca - clasa de risc II', 0.3)

		select*
		from Impozite


		delete
		from Staff


		INSERT INTO Staff (nume, prenume, email, telefon) VALUES 
		('Popescu', 'Alex', 'alex.popescu@example.com', '0744555666'),
		('Ionescu', 'Maria', 'maria.ionescu@example.com', '0733666777'),
		('Georgescu', 'Andrei', 'andrei.georgescu@example.com', '0711223344'),
		('Stanescu', 'Elena', 'elena.stanescu@example.com', '0722333444'),
		('Dumitrescu', 'Ion', 'ion.dumitrescu@example.com', '0755667788'),
		('Popa', 'Maria', 'maria.popa@example.com', '0766777888'),
		('Mihai', 'Vlad', 'vlad.mihai@example.com', '0711223344'),
		('Gheorghe', 'Andreea', 'andreea.gheorghe@example.com', '0744555666'),
		('Radu', 'Ioana', 'ioana.radu@example.com', '0755667788'),
		('Popescu', 'Mihai', 'mihai.popescu@example.com', '0766777888');

		select*
		from Staff

		select*
		from Functii


		INSERT INTO Repartizare_functii (ID_functie, ID_staff) VALUES 
		(4,13 ),
		(5,14),
		(6,15),
		(7,16),
		(8,17),
		(9,18),
		(10,19),
		(11,20),
		(12,21),
		(13, 22)

		select*
		from Repartizare_functii

		select*
		from Avioane
		
		select*
		from Aeroporturi

		

		INSERT INTO Zboruri (ID_avion, ora, data_plecare, durata, ID_aeroport) VALUES
		(1, '09:00', '2023-12-10', 120, 4),
		(2, '12:30', '2023-12-11', 180, 5),
		(3, '14:45', '2023-12-12', 90, 6),
		(4, '08:00', '2023-12-13', 240, 7),
		(5, '10:15', '2023-12-14', 150, 8),
		(6, '15:30', '2023-12-15', 180, 9),
		(7, '11:00', '2023-12-16', 120, 10),
		(8, '19:00', '2023-12-17', 360, 11),
		(9, '02:00', '2023-12-18', 540, 12),
		(10, '05:30', '2023-12-19', 480, 13);


		select*
		from Zboruri

		
		select*
		from Functii


		alter table Tasks
		alter column nume varchar(100)

		INSERT INTO Tasks (nume) VALUES
		('Verificarea tehnică a aeronavei înainte de decolare'),
		('Asigurarea siguranței pasagerilor și a aeronavei'),
		('Încărcarea și descărcarea bagajelor'),
		('Aprovizionarea aeronavei cu combustibil și alte provizii necesare'),
		('Îmbarcarea pasagerilor'),
		('Verificarea biletelor și a documentelor pasagerilor'),
		('Rezolvarea problemelor și întâmpinarea nevoilor pasagerilor'),
		('Urmărirea plăților și a încasărilor și întocmirea rapoartelor financiare'),
		('Gestionarea aprovizionării cu combustibil')

		select*
		from Tasks

		select*
		from Zboruri

		alter table TasksperZbor
		add ID_tasksperzbor int IDENTITY(1,1) primary key

		INSERT INTO TasksperZbor (ID_task, ID_zbor) VALUES
		(9,12), (10,13), (11,14), (12,15), (13,16), (8,17), (8,18), (9,19), (10,20), (11,21)

		select*
		from TasksperZbor

		select*
		from Calatori

		select*
		from Staff


		INSERT INTO Contracte (ID_angajat, descriere) VALUES 
		(13, 'Contract de munca pe perioada nedeterminata'),
		(14, 'Contract de munca pe perioada determinata'),
		(15, 'Contract de colaborare'),
		(16, 'Contract de prestari servicii'),
		(17, 'Contract de ucenicie'),
		(18, 'Contract de munca pe perioada determinata'),
		(19, 'Contract de munca in regim de munca flexibil'),
		(20, 'Contract de munca pe perioada determinata'),
		(21, 'Contract de munca pe perioada nedeterminata'),
		(22, 'Contract de munca pe perioada nedeterminata')

		select*
		from Contracte


		select*
		from Bilete
		select*
		from Zboruri
		select*
		from BiletePerZbor

		INSERT INTO BiletePerZbor (id_bilet, id_zbor) VALUES
		(8, 14),
		(9, 14),
		(10, 14),
		(11, 15),
		(12, 15),
		(13, 15),
		(14, 15),
		(15, 16),
		(16, 16),
		(17, 16);

		select*
		from Staff
		
		
		select*
		from Tasks

		select*
		from Functii

		
		

		INSERT INTO StaffTasks (ID_staff, ID_task) VALUES
		(13,16),
		(14,14),
		(15,15),
		(16,8),
		(17,12),
		(17,13),
		(18,8),
		(19,14),
		(20,9),
		(20,10),
		(21,11),
		(22,16);


		select*
		from Contracte 
		select* 
		from Impozite

		INSERT INTO ContracteImpozite (ID_contract, ID_impozit) VALUES
		(7,14),
		(8,14),
		(7,15),
		(7,16),
		(8,15),
		(8,16),
		(9,14),
		(10,14),
		(11,14),
		(12,14),
		(13,14),
		(9,15),
		(16,21),
		(16,15),
		(16,14),
		(14,15),
		(14,18),
		(15,15),
		(15,19);


		select*
		from Zboruri 
		select*
		from Gates

		INSERT INTO ZboruriGates(ID_zbor, ID_gate) VALUES
		(12,14),
		(12,24),
		(13,15),
		(14,16),
		(15,17),
		(16, 18),
		(17,19),
		(18,20),
		(19,21),
		(20,22),
		(21,23);
		
		

		
		SELECT nume_tara 
		FROM Tari;

		SELECT*
		FROM Zboruri
		WHERE durata > 120

		SELECT Nume, Prenume
		FROM Calatori
		WHERE Telefon LIKE '%0' or Telefon LIKE '%2' or Telefon LIKE '%4' or 
		Telefon LIKE '%6' or Telefon LIKE '%8'
		
		select*
		from Avioane

		select*
		from Companii

		SELECT*
		FROM Avioane 
		WHERE model like 'B%'

		SELECT*
		FROM Calatori

		SELECT Companii.nume_companie AS 'Nume companie', Zboruri.ID_zbor, Zboruri.ora, Zboruri.data_plecare, Zboruri.durata, 
		Aeroporturi.nume AS 'Nume aeroport sosire',  Tari.nume_tara AS 'Nume tara'
		FROM Zboruri
		INNER JOIN Aeroporturi ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
		INNER JOIN Locatii  ON Aeroporturi.ID_oras = Locatii.ID_locatie
		INNER JOIN Tari  ON Tari.ID_tara = Locatii.ID_tara
		INNER JOIN Avioane ON Zboruri.ID_avion = Avioane.ID_avion
		INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie;
		

		SELECT Zboruri.ID_zbor, Zboruri.data_plecare, Zboruri.data_plecare, Zboruri.ora, Zboruri.durata, Gates.numar AS 'Numar terminal'
		FROM Gates
		INNER JOIN ZboruriGates ON Gates.ID_gate = ZboruriGates.ID_gate
		INNER JOIN Zboruri ON  ZboruriGates.ID_zbor = Zboruri.ID_zbor

		select*
		from Bilete

		select* 
		FROM BiletePerZbor


SELECT Calatori.nume, Calatori.prenume, Companii.nume_companie
FROM Calatori
INNER JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
INNER JOIN Zboruri ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
INNER JOIN Avioane ON Zboruri.ID_avion = Avioane.ID_avion 
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Air France'

SELECT Staff.nume, Staff.prenume, Departamente.denumire 
FROM Staff 
INNER JOIN Repartizare_functii ON Staff.ID_staff = Repartizare_functii.ID_staff
INNER JOIN Functii ON  Repartizare_functii.ID_functie = Functii.ID_functie
INNER JOIN Departamente  ON Functii.ID_departament = Departamente.ID_departament
WHERE Departamente.denumire = 'Mentenanta'

SELECT DAY(Zboruri.data_plecare) AS 'Zi plecare', Zboruri.durata, Zboruri.ora, Tasks.nume AS 'Denumire task'
FROM Zboruri
INNER JOIN TasksperZbor ON TasksperZbor.ID_zbor = Zboruri.ID_zbor
INNER JOIN Tasks ON TasksperZbor.ID_task = Tasks.ID_task
WHERE MONTH(Zboruri.data_plecare) = 12
ORDER BY DAY(Zboruri.data_plecare) asc;

select*
from Tasks

select*
from Staff

select*
from Departamente

SELECT COUNT(Companii.nume_companie) AS 'Bilete vandute de Alitalia'
FROM Calatori
INNER JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
INNER JOIN Zboruri ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
INNER JOIN Avioane ON Zboruri.ID_avion = Avioane.ID_avion 
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'

SELECT AVG(Bilete.pret_bilet) AS 'Media cost bilet spre Paris'
FROM Calatori
INNER JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
INNER JOIN Zboruri ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
INNER JOIN Aeroporturi ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
INNER JOIN Locatii ON Aeroporturi.ID_oras = Locatii.ID_locatie
WHERE Locatii.nume_locatie = 'Roma'

SELECT Locatii.nume_locatie, Bilete.pret_bilet
FROM Calatori
INNER JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
INNER JOIN Zboruri ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
INNER JOIN Aeroporturi ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
INNER JOIN Locatii ON Aeroporturi.ID_oras = Locatii.ID_locatie
WHERE Locatii.nume_locatie = 'Roma'

SELECT C.nume_clasa, COUNT(B.ID_bilet) AS numar_bilete
FROM Clase C
LEFT JOIN Bilete B ON C.ID_clasa = B.ID_clasa
GROUP BY C.nume_clasa;

SELECT T.nume_tara, COUNT(L.ID_locatie) AS numar_orase
FROM Tari T
LEFT JOIN Locatii L ON T.ID_tara = L.ID_tara
GROUP BY T.nume_tara;

SELECT TOP 5 a.nume, COUNT(*) AS numar_zboruri
FROM Zboruri z
JOIN Aeroporturi a ON z.ID_aeroport = a.ID_aeroport
GROUP BY a.nume
ORDER BY numar_zboruri DESC


SELECT z.ID_zbor, SUM(b.pret_bilet) AS 'Suma incasata'
FROM Zboruri z JOIN BiletePerZbor bpz ON z.ID_zbor = bpz.id_zbor 
JOIN Bilete b ON bpz.id_bilet = b.ID_bilet 
GROUP BY z.ID_zbor 
ORDER BY 'Suma incasata' DESC;

SELECT T.nume_tara, COUNT(L.ID_locatie) AS 'Numar Orașe'
FROM Tari T
JOIN Locatii L ON T.ID_tara = L.ID_tara
GROUP BY T.nume_tara
HAVING COUNT(L.ID_locatie) > 1;

SELECT CA.nume, CA.prenume
FROM Calatori CA
JOIN Bilete B ON CA.ID_calator = B.ID_calator
GROUP BY CA.nume, CA.prenume
HAVING SUM(B.pret_bilet) > 500;

SELECT C.nume_companie, COUNT(Z.ID_zbor) AS NumarZboruri
FROM Companii C
JOIN Avioane A ON C.ID_companie = A.ID_companie
JOIN Zboruri Z ON A.ID_avion = Z.ID_avion
GROUP BY C.nume_companie
HAVING COUNT(Z.ID_zbor) < 2;

SELECT Calatori.nume, Calatori.prenume, COUNT(Bilete.ID_bilet) as total_bilete
FROM Calatori
JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
GROUP BY Calatori.nume, Calatori.prenume
HAVING COUNT(Bilete.ID_bilet) > 1;

select*
from Calatori
select*
from Clase

select*
from Bilete
select*
from  Zboruri

select*
from BiletePerZbor

Insert into Bilete(pret_bilet,ID_calator, ID_clasa) Values (300,66,3)

Insert into BiletePerZbor(id_bilet,id_zbor) values(18,21)


select*
from Zboruri

SELECT Zboruri.ID_zbor, Zboruri.ora, Zboruri.durata, Aeroporturi.nume, Locatii.nume_locatie
FROM Zboruri
INNER JOIN Aeroporturi ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
INNER JOIN Locatii ON Aeroporturi.ID_oras = Locatii.ID_locatie
WHERE Zboruri.data_plecare = '2023-12-10'
ORDER BY Zboruri.ora ASC;

SELECT Companii.nume_companie
FROM Companii
INNER JOIN Avioane ON Companii.ID_companie = Avioane.ID_companie
WHERE Avioane.capacitate >= 200
GROUP BY Companii.nume_companie;

SELECT Departamente.denumire
FROM Departamente
INNER JOIN Functii ON Departamente.ID_departament = Functii.ID_departament
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_functie = Functii.ID_functie
INNER JOIN Staff ON Staff.ID_staff = Repartizare_functii.ID_staff
WHERE Functii.salariu_brut > 2000
GROUP BY Departamente.denumire

select*
from Avioane

SELECT Companii.nume_companie, COUNT(Avioane.ID_avion) as numar_avioane
FROM Companii
INNER JOIN Avioane ON Companii.ID_companie = Avioane.ID_companie
WHERE Avioane.model = 'Airbus A340'
GROUP BY Companii.nume_companie;





INSERT INTO Avioane(model, capacitate, ID_companie, ID_avion) VALUES('Airbus A340',380, 18, 11)
INSERT INTO Avioane(model, capacitate, ID_companie, ID_avion) VALUES('Airbus A340',380, 14, 12)


SELECT Companii.nume_companie
FROM Companii
INNER JOIN Avioane ON Avioane.ID_companie = Companii.ID_companie
INNER JOIN Zboruri ON Zboruri.ID_avion = Avioane.ID_avion 
WHERE Zboruri.durata > 100
Group BY  Companii.nume_companie

SELECT Staff.nume, Staff.prenume
FROM Staff
INNER JOIN Contracte ON Contracte.ID_angajat = Staff.ID_staff
INNER JOIN ContracteImpozite ON ContracteImpozite.ID_contract =Contracte.ID_contract
INNER JOIN Impozite ON Impozite.ID_impozit = Contracte.ID_contract
WHERE Impozite.nume = 'Contributie la CAS'




select*
From Impozite


WITH CTEBilete AS (
  SELECT Bilete.*, Clase.NUME_CLASA
  FROM Bilete
  INNER JOIN Clase ON Clase.ID_clasa = Bilete.ID_clasa
  WHERE Clase.NUME_CLASA = 'BUSINESS'
)
SELECT Calatori.*
FROM Calatori
INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator;

WITH OrasDestinatie AS (
  SELECT ID_locatie
  FROM Locatii
  WHERE nume_locatie = 'Barcelona'
)
SELECT Zboruri.*
FROM Zboruri
INNER JOIN Aeroporturi ON Aeroporturi.ID_aeroport = Zboruri.ID_aeroport
INNER JOIN OrasDestinatie ON OrasDestinatie.ID_locatie = Aeroporturi.ID_oras;


select*
from Locatii

WITH ZboruriAvion AS (
  SELECT z.ID_zbor, a.model, z.data_plecare, z.ora
  FROM Zboruri z
  JOIN Avioane a ON z.ID_avion = a.ID_avion
)
SELECT * FROM ZboruriAvion WHERE model = 'Boeing 747';

WITH InfoZboruri AS (
SELECT Z.ID_zbor, Z.data_plecare, Z.ora, A1.nume AS aeroport_destinatie, C.nume_companie, A.model
FROM Zboruri Z
JOIN Aeroporturi A1 ON Z.ID_aeroport=A1.ID_aeroport
JOIN Avioane A ON Z.ID_avion=A.ID_avion
JOIN Companii C ON A.ID_companie=C.ID_companie)
SELECT *
FROM InfoZboruri;


WITH CTEmax AS
(
	SELECT MONTH(Zboruri.data_plecare) AS Luna, COUNT(Bilete.ID_bilet) AS Maxim
	FROM Zboruri 
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
	INNER JOIN Bilete ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	GROUP BY MONTH(Zboruri.data_plecare)
)
SELECT Luna, Maxim
FROM CTEmax

select*
from Zboruri

UPDATE Zboruri
SET  data_plecare = '2023-11-19'
WHERE data_plecare = '2023-12-19'


drop trigger trg_update_ora_zbor

WITH CTE_NumarCalatoriPerZbor AS (
SELECT Z.ID_zbor, COUNT(B.ID_bilet) AS NumarCalatori
FROM Zboruri Z
INNER JOIN BiletePerZbor BPZ ON Z.ID_zbor = BPZ.id_zbor
INNER JOIN Bilete B ON BPZ.id_bilet = B.ID_bilet
GROUP BY Z.ID_zbor
)
SELECT * FROM CTE_NumarCalatoriPerZbor;


select*
from Zboruri

select*
from Bilete


WITH CTE AS (
SELECT TOP 1 WITH TIES z.ID_zbor, z.durata, b.pret_bilet
FROM Zboruri z
JOIN BiletePerZbor bz ON bz.id_zbor = z.ID_zbor
JOIN Bilete b ON b.ID_bilet = bz.id_bilet
ORDER BY z.durata DESC, b.pret_bilet ASC
)
SELECT z.ID_zbor, a.nume AS aeroport, l.nume_locatie AS destinatie, c.nume_companie,
av.model AS model_avion, z.ora, z.data_plecare, z.durata, b.pret_bilet
FROM Zboruri z
JOIN CTE ON CTE.ID_zbor = z.ID_zbor
JOIN Aeroporturi a ON a.ID_aeroport = z.ID_aeroport
JOIN Locatii l ON l.ID_locatie = a.ID_oras
JOIN Avioane av ON av.ID_avion = z.ID_avion
JOIN Companii c ON c.ID_companie = av.ID_companie
JOIN BiletePerZbor bz ON bz.id_zbor = z.ID_zbor
JOIN Bilete b ON b.ID_bilet = bz.id_bilet;

select*
from Staff


UPDATE Staff
SET nume = 'Petrescu'
WHERE nume = 'Ionescu' and prenume = 'Maria'

DECLARE @newdiscount REAL;
SET @newdiscount = 0.05;
UPDATE Bilete
SET pret_bilet -=  @newdiscount*pret_bilet
FROM Bilete 
INNER JOIN BiletePerZbor ON Bilete.ID_bilet = BiletePerZbor.id_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'
SELECT @newdiscount

SELECT Companii.nume_companie, Bilete.pret_bilet
FROM Bilete 
INNER JOIN BiletePerZbor ON Bilete.ID_bilet = BiletePerZbor.id_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'


select*
from Companii

SELECT Companii.nume_companie, Bilete.pret_bilet
FROM Calatori
INNER JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
INNER JOIN Zboruri ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
INNER JOIN Avioane ON Zboruri.ID_avion = Avioane.ID_avion 
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'



select * from Staff
DECLARE @Counter INT ,
@MaxId INT,
@email as varchar(50);
SELECT @Counter = min(Staff.ID_staff) ,
@MaxId = max(Staff.ID_staff)
FROM Staff
WHILE( @Counter <= @MaxId)
BEGIN
 update S
 set S.email = S.nume+ '.' + SUBSTRING(S.prenume,1,1)  + '@aero.com'
 from Staff as S
 select @email = email from Staff where Staff.ID_staff = @Counter
 PRINT CONVERT(VARCHAR,@Counter) + '. employee''s email address is ' + @email 
 SET @Counter = @Counter + 1 
END
select * from Staff

DECLARE @newprenume varchar(30);
UPDATE Staff
SET Staff.prenume = CONCAT('M', prenume)---Substring(prenume,3,100)--CONCAT('M', prenume)
SELECT @newprenume = prenume
FROM Staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
WHERE Departamente.denumire = 'Mentenanta'

select Staff.*, Departamente.denumire
from Staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
WHERE Departamente.denumire = 'Mentenanta'

UPDATE Staff
Set prenume = 'Elena'
where ID_staff = 16

select*
from Clase
SELECT Bilete.ID_bilet, Companii.nume_companie, Clase.NUME_CLASA
FROM Bilete
INNER JOIN Clase ON Clase.ID_clasa = Bilete.ID_clasa
INNER JOIN BiletePerZbor ON Bilete.ID_bilet = BiletePerZbor.id_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'

UPDATE Clase
SET Clase.NUME_CLASA = 'ECONOMIC'
FROM Bilete 
INNER JOIN Clase ON Clase.ID_clasa = Bilete.ID_clasa
INNER JOIN BiletePerZbor ON Bilete.ID_bilet = BiletePerZbor.id_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'

SELECT Bilete.ID_bilet, Companii.nume_companie, Clase.NUME_CLASA
FROM Bilete
INNER JOIN Clase ON Clase.ID_clasa = Bilete.ID_clasa
INNER JOIN BiletePerZbor ON Bilete.ID_bilet = BiletePerZbor.id_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Alitalia'

SELECT*
FROM Avioane

UPDATE Avioane
SET model = 'Airbus A380', capacitate = '400'
WHERE ID_avion = 9;

SELECT*
FROM Avioane


select*
from zboruri

UPDATE Zboruri
SET durata = 120
WHERE ID_zbor = 13;

select*
from zboruri


select Avioane.capacitate, Companii.nume_companie
FROM Avioane
JOIN Companii ON Avioane.ID_companie = Companii.ID_companie

UPDATE Avioane
SET capacitate = 300
FROM Avioane
JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Air France';

select Avioane.capacitate, Companii.nume_companie
FROM Avioane
JOIN Companii ON Avioane.ID_companie = Companii.ID_companie


SELECT Staff.*, Departamente.denumire AS Departament, Functii.salariu_brut
FROM Staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff =Staff.ID_staff
INNER JOIN Functii ON Functii.ID_functie = Repartizare_functii.ID_functie
INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
WHERE Departamente.denumire = 'Marketing'

UPDATE Functii
SET  salariu_brut = salariu_brut * 1.1
FROM Functii
JOIN Departamente ON Functii.ID_departament = Departamente.ID_departament
WHERE Departamente.denumire = 'Marketing';

SELECT Staff.*, Departamente.denumire AS Departament, Functii.salariu_brut
FROM Staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff =Staff.ID_staff
INNER JOIN Functii ON Functii.ID_functie = Repartizare_functii.ID_functie
INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
WHERE Departamente.denumire = 'Marketing'


select*
from Zboruri

UPDATE Zboruri
SET durata = durata + 30
WHERE durata > 400;

select*
from Zboruri


UPDATE Tasks
SET nume = 'Actualizarea strategiei de marketing'
FROM Tasks
INNER JOIN StaffTasks ON Tasks.ID_task = StaffTasks.ID_task
--INNER JOIN Staff ON Staff.ID_staff = StaffTasks.ID_staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = StaffTasks.ID_staff
INNER JOIN Functii ON Functii.ID_functie = Repartizare_functii.ID_functie
INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
WHERE Departamente.denumire= 'Marketing'

SELECT Calatori.*
FROM Calatori
INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator
INNER JOIN Clase ON Bilete.ID_clasa = Clase.ID_clasa




UPDATE Bilete
SET ID_clasa = (SELECT ID_clasa FROM Clase WHERE NUME_CLASA = 'BUSINESS')
WHERE ID_calator IN (
    SELECT B.ID_calator
    FROM Bilete B
    INNER JOIN Clase C ON B.ID_clasa = C.ID_clasa AND C.NUME_CLASA = 'ECONOMIC'
    INNER JOIN Calatori Cl ON B.ID_calator = Cl.ID_calator AND Cl.SEX = 'FEMININ'
);

SELECT Calatori.*, Clase.NUME_CLASA AS Clasa
FROM Calatori
INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator
INNER JOIN Clase ON Bilete.ID_clasa = Clase.ID_clasa


UPDATE Zboruri
SET ora = '10:00'
FROM Zboruri
INNER JOIN Avioane ON Zboruri.ID_avion = Avioane.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Lufthansa';


select Zboruri.*, Companii.nume_companie
FROM Zboruri
INNER JOIN Avioane ON Zboruri.ID_avion = Avioane.ID_avion
INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
WHERE Companii.nume_companie = 'Lufthansa';

select*
FROM ZboruriGates

UPDATE ZboruriGates
SET ID_gate = 24
WHERE ID_zbor = 12 

select*
FROM ZboruriGates


select* 
from Zboruri

UPDATE Zboruri
SET ora = DATEADD(hour, 1, ora)
WHERE data_plecare = '2023-12-10'

select* 
from Zboruri

select*
from Departamente


-- identificam ID-ul companiei 'Blue Air'
SELECT ID_companie FROM Companii WHERE nume_companie = 'Blue Air';

-- identificam zborurile cu ID-ul companiei 'Blue Air'
SELECT * FROM Zboruri WHERE ID_avion IN (SELECT ID_avion FROM Avioane WHERE ID_companie = (SELECT ID_companie FROM Companii WHERE nume_companie = 'Blue Air'));

-- actualizam biletele cu clasa ECONOMIC pentru zborurile companiei 'Blue Air'


UPDATE Calatori SET adresa = 'Noua adresa' 
WHERE ID_calator = 4;

insert into Tari(nume_tara) values ('armenia') 

select*
from Tari

UPDATE Tari
SET nume_tara = UPPER(LEFT(nume_tara, 1)) + SUBSTRING(nume_tara, 2, LEN(nume_tara))
WHERE LOWER(LEFT(nume_tara, 1)) = LEFT(nume_tara, 1)

select*
from Functii

select Contracte.descriere, Functii.nume AS Functie
from Contracte
INNER JOIN Staff ON Contracte.ID_angajat = Staff.ID_staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
WHERE Functii.nume =  'Manager'

UPDATE Contracte 
SET descriere = CONCAT(descriere, '. 40 de ore de munca pe saptamana')
FROM Contracte
INNER JOIN Staff ON Contracte.ID_angajat = Staff.ID_staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
WHERE Functii.nume =  'Manager'

select Contracte.descriere, Functii.nume AS Functie
from Contracte
INNER JOIN Staff ON Contracte.ID_angajat = Staff.ID_staff
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
WHERE Functii.nume =  'Manager'


alter table Contracte
alter column descriere varchar(100)

select*
from Tari

DELETE FROM Tari WHERE ID_tara NOT IN
(SELECT ID_tara FROM Locatii GROUP BY ID_tara HAVING COUNT(ID_locatie) = 0)

select*
from Tari

SET IDENTITY_INSERT Tari ON;


INSERT INTO Tari (ID_tara,nume_tara) VALUES
(1, 'Italia'),
(7,'Romania'),
(8,'SUA'),
(9, 'Spain'),
(10, 'Marea Britanie'),
(11, 'Germania'),
(12, 'Japonia'),
(13, 'China'),
(14, 'Rusia');

INSERT INTO Locatii (ID_tara, nume_locatie) VALUES
(1, 'Venetia'),
(7, 'Bucuresti'),
(8, 'New York'),
(1, 'Roma'),
(9, 'Barcelona'),
(10, 'Londra'),
(11, 'Berlin'),
(12, 'Tokyo'),
(13, 'Beijing'),
(14, 'Moscova');



INSERT INTO Aeroporturi (nume, ID_oras) VALUES 
('Marco Polo', 31),
('Henri Coanda', 22),
('JFK', 23),
('Fiumicino', 24),
('El Prat', 25),
('Heathrow', 26),
('Tegel', 27),
('Narita', 28),
('Beijing Capital', 29),
('Sheremetyevo', 30)

drop trigger  trg_InsertTaskOnNewFlight

INSERT INTO Zboruri (ID_avion, ora, data_plecare, durata, ID_aeroport) VALUES
		(1, '09:00', '2023-12-10', 120, 34),
		(2, '12:30', '2023-12-11', 180, 35),
		(3, '14:45', '2023-12-12', 90, 36),
		(4, '08:00', '2023-12-13', 240, 37),
		(5, '10:15', '2023-12-14', 150, 38),
		(6, '15:30', '2023-12-15', 180, 39),
		(7, '11:00', '2023-12-16', 120, 40),
		(8, '19:00', '2023-12-17', 360, 41),
		(9, '02:00', '2023-12-18', 540, 42),
		(10, '05:30', '2023-12-19', 480, 43);



SELECT*
FROM Zboruri

DELETE FROM Locatii WHERE ID_tara IS NULL

select*
from Locatii


INSERT INTO ZboruriGates(ID_zbor, ID_gate) VALUES
		(72,14),
		(72,24),
		(63,15),
		(64,16),
		(65,17),
		(66, 18),
		(67,19),
		(68,20),
		(69,21),
		(70,22),
		(71,23);


		 INSERT INTO BiletePerZbor (id_bilet, id_zbor) VALUES
		(8, 64),
		(9, 64),
		(10, 64),
		(11, 65),
		(12, 65),
		(13, 65),
		(14, 65),
		(15, 66),
		(16, 66),
		(17, 66);


		INSERT INTO TasksperZbor (ID_task, ID_zbor) VALUES
(9,72), (10,63), (11,64), (12,65), (13,66), (8,67), (8,68), (9,69), (10,70), (11,71)


--if OBJECT_ID('Destinatii', 'V') is not null
	--drop view Destinatii


	IF OBJECT_ID ('Destinatii', 'V') IS NOT NULL
	DROP VIEW Destinatii

GO

create view Destinatii (Aeroport, Locatie, Tara)
as
	select Aeroporturi.nume , Locatii.nume_locatie, Tari.nume_tara 
	from Aeroporturi
	INNER JOIN Locatii ON Locatii.ID_locatie = Aeroporturi.ID_oras
	INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_tara

GO

select * from Destinatii

	IF OBJECT_ID ('Pasageri', 'V') IS NOT NULL
	DROP VIEW Pasageri

GO 
CREATE VIEW Pasageri
as 
	select Calatori.nume AS Prenume, Calatori.prenume AS Nume, Clase.NUME_CLASA AS Clasa, Zboruri.durata AS 'Durata zbor', Zboruri.data_plecare AS Data, Zboruri.ora AS Ora
	FROM Calatori
	INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator
	INNER JOIN Clase ON Bilete.ID_clasa = Clase.ID_clasa
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	INNER JOIN Zboruri ON BiletePerZbor.id_zbor = Zboruri.ID_zbor


	select*
	 from Pasageri

	IF OBJECT_ID ('Angajati', 'V') IS NOT NULL
	DROP VIEW Angajati


	 GO 
CREATE VIEW Angajati
as 
	select Staff.nume AS Nume, Staff.prenume AS Prenume, Functii.ID_functie AS Functie, Departamente.denumire AS Departament
	from Staff
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Functii.ID_functie =  Repartizare_functii.ID_functie
	INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament

	select*
	 from Angajati
	 IF OBJECT_ID('OrganizareZboruri', 'V') IS NOT NULL DROP View OrganizareZboruri

	 GO 
	 CREATE VIEW OrganizareZboruri
	 as
	 SELECT Companii.nume_companie AS Companie , Zboruri.data_plecare AS DataPlecare, Zboruri.durata AS Durata, Zboruri.ora AS Ora, Avioane.model AS Avion 
	 FROM Companii
	 INNER JOIN Avioane ON Avioane.ID_companie = Companii.ID_companie
	 INNER JOIN Zboruri ON Zboruri.ID_avion = Avioane.ID_avion

	select*
	 from OrganizareZboruri

	 IF OBJECT_ID ('Responsabiliti', 'V') IS NOT NULL
	DROP VIEW Responsabiliti


	  GO 
CREATE VIEW Responsabiliti
as 
	select Staff.nume AS Nume, Staff.prenume AS Prenume, Tasks.nume AS Task 
	from Staff
	INNER JOIN StaffTasks ON Staff.ID_staff  = StaffTasks.ID_staff
	INNER JOIN Tasks ON StaffTasks.ID_task = Tasks.ID_task

	select*
	 from Responsabiliti


	 SET IMPLICIT_TRANSACTIONS ON
	 DECLARE @err int;
	 DELETE 
	 FROM Locatii
	 WHERE Locatii.ID_tara is NULL
	 ROLLBACK;

	 select*
	 from Calatori

	 select*
	 from Bilete
	 

	 DELETE Bilete
	 FROM Bilete
	 INNER JOIN Calatori ON Bilete.ID_calator = Calatori.ID_calator
	 WHERE Calatori.CNP = '1234567890132'

	select*
	from Zboruri

	INSERT INTO Zboruri(ID_avion,ID_aeroport, ora, data_plecare, durata) values
	(1,34,'12:30','2023-11-01','120') ,
	(2,35,'12:00', '2023-11-01', '180')

	DELETE 
	FROM Zboruri
	WHERE Zboruri.data_plecare = '2023-11-01'


	DELETE Staff
	FROM Staff
	INNER JOIN Contracte ON Staff.ID_staff = Contracte.ID_angajat
	INNER JOIN StaffTasks ON Staff.ID_staff = StaffTasks.ID_staff
	WHERE Contracte.ID_contract = 15

	select*
	from Contracte

	select*
	FROM Staff
	INNER JOIN Contracte ON Staff.ID_staff = Contracte.ID_angajat
	INNER JOIN StaffTasks ON Staff.ID_staff = StaffTasks.ID_staff
	WHERE Contracte.ID_contract = 15

	DELETE Tasks 
	FROM Tasks
	INNER JOIN StaffTasks ON StaffTasks.ID_task = Tasks.ID_task
	INNER JOIN Staff ON StaffTasks.ID_staff = Staff.ID_staff
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
	INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
	WHERE Departamente.denumire = 'Marketing'

	select Departamente.denumire AS Departament, Tasks.nume AS Task
		FROM Tasks
	INNER JOIN StaffTasks ON StaffTasks.ID_task = Tasks.ID_task
	INNER JOIN Staff ON StaffTasks.ID_staff = Staff.ID_staff
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
	INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
	WHERE Departamente.denumire = 'Siguranta'

	select*
	from Departamente


	DELETE Bilete
	FROM Tari 
	INNER JOIN Locatii ON Locatii.ID_tara = Tari.ID_tara
	INNER JOIN Aeroporturi ON Aeroporturi.ID_oras = Locatii.ID_locatie
	INNER JOIN Zboruri ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
	INNER JOIN Bilete ON Bilete.ID_bilet = BiletePerZbor.id_bilet
	WHERE Tari.nume_tara = 'Italia'
	ROLLBACK;

	select Bilete.ID_bilet, Tari.nume_tara
	FROM Bilete
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
	INNER JOIN Aeroporturi ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
	INNER JOIN Locatii ON Locatii.ID_locatie = Aeroporturi.ID_oras
	INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_locatie
	WHERE Tari.nume_tara = 'SUA'

	select Bilete.ID_bilet, Tari.nume_tara
	FROM Bilete
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
	INNER JOIN Aeroporturi ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
	INNER JOIN Locatii ON Locatii.ID_locatie = Aeroporturi.ID_oras
	INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_locatie
	WHERE Tari.nume_tara = 'Italia'

	SELECT Tari.nume_tara, Bilete.ID_bilet, Bilete.pret_bilet
	FROM Tari 
	INNER JOIN Locatii ON Locatii.ID_tara = Tari.ID_tara
	INNER JOIN Aeroporturi ON Aeroporturi.ID_oras = Locatii.ID_locatie
	INNER JOIN Zboruri ON Zboruri.ID_aeroport = Aeroporturi.ID_aeroport
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_zbor = Zboruri.ID_zbor
	INNER JOIN Bilete ON Bilete.ID_bilet = BiletePerZbor.id_bilet
	WHERE Tari.nume_tara = 'Italia'

	select*
	from Aeroporturi


	select*
	from Avioane

	select*
	from Bilete

	select*
	from Zboruri

	INSERT INTO Zboruri(ID_avion, ID_aeroport, data_plecare, durata, ora) values (2, 37, '2023-10-10', 100 ,'10:10')

	INSERT INTO Calatori(nume,prenume, CNP, email, sex, adresa, telefon) VALUES 
	('Pop', 'Ana', '2990500123456', 'anapopescu@gmail.com', 'FEMININ', 'Strada Libertatii, Bucuresti', '0770985467')

	INSERT INTO Bilete(ID_clasa,ID_calator, pret_bilet) VALUES (3, 86, 300) 

	INSERT INTO BiletePerZbor(id_bilet, id_zbor) Values (20, 75)

	drop trigger tr_check_telefon
	
	delete Bilete
	Where ID_bilet = 15
	delete Bilete
	Where ID_bilet = 16
	delete Bilete
	Where ID_bilet = 19
	delete Bilete
	Where ID_bilet = 20

	select Staff.*
	 FROM Staff
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
	INNER JOIN StaffTasks ON StaffTasks.ID_staff = Staff.ID_staff
	WHERE StaffTasks.ID_task is null 

	DELETE Staff
	FROM Staff
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
	INNER JOIN StaffTasks ON StaffTasks.ID_staff = Staff.ID_staff
	WHERE Functii.nume = 'Manager' and StaffTasks.ID_task is null 

	INSERT INTO Staff (nume, prenume, telefon , email) VALUES ('Andronic', 'Catrina', '0787546366', 'andronic.c@gmail.com')
	select*
	from Staff
	INSERT INTO Repartizare_functii(ID_functie, ID_staff) VALUES (4,26 )
	INSERT INTO StaffTasks(ID_staff) VALUES(26)
	SET IMPLICIT_TRANSACTIONS ON
	
	DELETE Calatori
	FROM Calatori
	INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
	INNER JOIN Avioane ON Zboruri.ID_zbor = Zboruri.ID_zbor
	INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
	WHERE Companii.nume_companie = 'Air France'
	ROLLBACK;

	select Calatori.nume, Calatori.prenume ,Companii.nume_companie
	FROM Calatori
	INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
	INNER JOIN Avioane ON Zboruri.ID_zbor = Zboruri.ID_zbor
	INNER JOIN Companii ON Avioane.ID_companie = Companii.ID_companie
	WHERE Companii.nume_companie = 'Iberia'

	select*
	from Companii

	DELETE Contracte
	FROM Contracte
	INNER JOIN Staff ON Staff.ID_staff = Contracte.ID_angajat
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Functii.ID_functie = Repartizare_functii.ID_functie
	INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
	WHERE Contracte.descriere = 'Contract de munca pe perioada nedeterminata'and Departamente.denumire = 'Marketing'
	ROLLBACK;


	Select Contracte.descriere, Departamente.denumire
	FROM Contracte
	INNER JOIN Staff ON Staff.ID_staff = Contracte.ID_angajat
	INNER JOIN Repartizare_functii ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Functii ON Functii.ID_functie = Repartizare_functii.ID_functie
	INNER JOIN Departamente ON Departamente.ID_departament = Functii.ID_departament
	WHERE Contracte.descriere = 'Contract de munca pe perioada nedeterminata'


	SELECT Zboruri.*, Companii.nume_companie
	FROM Companii
	INNER JOIN Avioane On Avioane.ID_companie = Companii.ID_companie
	INNER JOIN Zboruri ON Zboruri.ID_avion = Avioane.ID_avion
	INNER JOIN Aeroporturi ON Aeroporturi.ID_aeroport = Zboruri.ID_aeroport
	INNER JOIN Locatii ON Locatii.ID_locatie = Aeroporturi.ID_oras
	INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_tara
	WHERE Tari.nume_tara = 'Italia' and Companii.nume_companie = 'Alitalia'

	SET IMPLICIT_TRANSACTIONS ON

	DELETE Zboruri
	FROM Companii
	INNER JOIN Avioane On Avioane.ID_companie = Companii.ID_companie
	INNER JOIN Zboruri ON Zboruri.ID_avion = Avioane.ID_avion
	INNER JOIN Aeroporturi ON Aeroporturi.ID_aeroport = Zboruri.ID_aeroport
	INNER JOIN Locatii ON Locatii.ID_locatie = Aeroporturi.ID_oras
	INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_tara
	WHERE Tari.nume_tara = 'Italia' and Companii.nume_companie = 'Alitalia'
	ROLLBACK;

	select*
	from Impozite


	SELECT Staff.*, Impozite.nume AS Impozit
	FROM IMPOZITE
	INNER JOIN ContracteImpozite ON ContracteImpozite.ID_impozit = Impozite.ID_impozit
	INNER JOIN Contracte ON Contracte.ID_contract = ContracteImpozite.ID_contract
	INNER JOIN Staff ON Staff.ID_staff = Contracte.ID_angajat
	WHERE Impozite.nume = 'Contributia la Fondul de risc si accidente de munca - clasa de risc II'
	

	DELETE Staff
	FROM IMPOZITE
	INNER JOIN ContracteImpozite ON ContracteImpozite.ID_impozit = Impozite.ID_impozit
	INNER JOIN Contracte ON Contracte.ID_contract = ContracteImpozite.ID_contract
	INNER JOIN Staff ON Staff.ID_staff = Contracte.ID_angajat
	WHERE Impozite.nume = 'Contributia la Fondul de risc si accidente de munca - clasa de risc II'
	ROLLBACK;


	SELECT STAFF.ID_staff, Staff.nume, Staff.prenume 
	FROM Staff
	INNER JOIN StaffTasks ON StaffTasks.ID_staff = Staff.ID_staff
	INNER JOIN Tasks ON StaffTasks.ID_task = Tasks.ID_task
	GROUP BY Staff.ID_staff, Staff.nume, Staff.prenume
	HAVING COUNT(Tasks.ID_task) > 1

	DELETE Staff
	FROM Staff
	WHERE (
	SELECT COUNT (*) As Cnt
	FROM StaffTasks AS ST
	WHERE  Staff.ID_staff = ST.ID_staff 
	) > 2 
	ROLLBACK;

	DELETE Companii
	FROM Companii
	WHERE (SELECT Companii.nume_companie, COUNT (Avioane.ID_avion) AS NR
	FROM Companii
	INNER JOIN Avioane ON Avioane.ID_companie = Companii.ID_companie
	GROUP BY Companii.nume_companie ) > 1
	ROLLBACK;



	SELECT Companii.nume_companie, COUNT (Avioane.ID_avion) AS NR
	FROM Companii
	INNER JOIN Avioane ON Avioane.ID_companie = Companii.ID_companie
	GROUP BY Companii.nume_companie 

	select*
	from Avioane

	INSERT INTO Avioane(ID_avion,ID_companie,capacitate, model) VALUES (13,12, 300, 'Cessna 172')

	DELETE Calatori
	FROM Calatori
	WHERE Calatori.telefon = '0770985467' 
	ROLLBACK;

	drop trigger trg_update_avioane_capacitate_delete
	drop trigger trig_stergere_calator
	drop trigger trig_stergere_calator

	select*
	FROM Calatori


	DELETE Locatii 
	FROM Locatii
	INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_tara
	WHERE Tari.nume_tara = 'SUA'
	ROLLBACK;

	select*
	from Gates

	BEGIN TRAN
INSERT INTO Gates (numar)
VALUES (25);
COMMIT

BEGIN TRANSACTION
UPDATE Functii SET salariu_brut = 12000 WHERE nume = 'Manager';
COMMIT;


BEGIN TRANSACTION
INSERT INTO Functii (nume, salariu_brut) VALUES ('Manager', 10000);
COMMIT;


BEGIN TRAN

DECLARE @pret_bilet INT
SET @pret_bilet = 250

INSERT INTO Bilete(ID_calator, ID_clasa, pret_bilet)
VALUES (3, 1, @pret_bilet);

DECLARE @id_bilet INT
SET @id_bilet = @@IDENTITY

INSERT INTO BiletePerZbor(id_bilet, id_zbor)
VALUES (@id_bilet, 4);




BEGIN TRY


BEGIN tran 
DECLARE @ID_tara INT
SELECT @ID_tara = ID_tara FROM Tari WHERE nume_tara = 'Romania'
INSERT INTO Locatii (ID_tara, nume_locatie) VALUES (@ID_tara, 'Bucuresti')
COMMIT tran


BEGIN TRY


BEGIN tran
INSERT INTO Functii (nume, salariu_brut) VALUES ('Manager', 10000);


END TRY
begin catch
if ERROR_NUMBER() = 2627 --error for duplicate key violation
begin
print 'Primary key violation';
end
else if ERROR_NUMBER() = 547 --constraint violations
begin
print 'Constraint violation';
end
else
begin
print 'Unhandled error';
end
if @@TRANCOUNT > 0
rollback tran
end catch

select*
from Aeroporturi


BEGIN TRANSACTION

DECLARE @ID_aeroport INT
DECLARE @ID_companie INT
DECLARE @ID_avion INT

-- Verificăm dacă orașul de destinație există în baza de date
IF NOT EXISTS (SELECT * FROM Locatii WHERE nume_locatie = 'Bucuresti' AND ID_tara = 7)
BEGIN
RAISERROR('Orașul de destinație nu este disponibil', 16, 1)
ROLLBACK TRANSACTION
RETURN
END

-- Verificăm dacă aeroportul există în baza de date
DECLARE @ID_oras INT = SCOPE_IDENTITY() 
SELECT @ID_aeroport = ID_aeroport FROM Aeroporturi WHERE nume = 'Henri Coanda' AND ID_oras = @ID_oras
IF @ID_aeroport IS NULL
BEGIN
RAISERROR('Aeroportul nu este disponibil', 16, 1)
ROLLBACK TRANSACTION
RETURN
END

-- Verificăm dacă compania aeriană există în baza de date
SELECT @ID_companie = ID_companie FROM Companii WHERE nume_companie = 'Blue Air'
IF @ID_companie IS NULL
BEGIN
RAISERROR('Compania aeriană nu este disponibilă', 16, 1)
ROLLBACK TRANSACTION
RETURN
END

-- Verificăm dacă există un avion disponibil pentru zborul respectiv
SELECT TOP 1 @ID_avion = ID_avion FROM Avioane WHERE ID_companie = @ID_companie AND capacitate >= 100 ORDER BY NEWID()
IF @ID_avion IS NULL
BEGIN
RAISERROR('Nu există avioane disponibile pentru acest zbor', 16, 1)
ROLLBACK TRANSACTION
RETURN
END

-- inserăm zborul în tabela Zboruri
INSERT INTO Zboruri (ID_avion, ora, data_plecare, durata, ID_aeroport) VALUES (@ID_avion, '08:00:00', '2023-05-13', 120, @ID_aeroport)

-- obținem ID-ul zborului inserat
DECLARE @ID_zbor INT = SCOPE_IDENTITY()

-- alocăm porțile de îmbarcare pentru zbor
INSERT INTO ZboruriGates (ID_zbor, ID_gate) VALUES (@ID_zbor, 1)
INSERT INTO ZboruriGates (ID_zbor, ID_gate) VALUES (@ID_zbor, 2)
INSERT INTO ZboruriGates (ID_zbor, ID_gate) VALUES (@ID_zbor, 3)

ROLLBACK TRANSACTION


SELECT Staff.nume , Staff.prenume, Impozite.nume
FROM Impozite
INNER JOIN ContracteImpozite ON ContracteImpozite.ID_impozit = Impozite.ID_impozit
INNER JOIN Contracte ON Contracte.ID_contract = ContracteImpozite.ID_contract
INNER JOIN Staff ON Staff.ID_staff = Contracte.ID_angajat
GROUP BY Staff.nume, Staff.prenume, Impozite.nume
HAVING Impozite.nume = 'Contributie la CAS'

select*
from Impozite

SELECT Calatori.nume, Calatori.prenume, Companii.nume_companie
FROM Calatori
INNER JOIN Bilete ON Calatori.ID_calator = Bilete.ID_calator
INNER JOIN BiletePerZbor ON Bilete.ID_bilet  = BiletePerZbor.id_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Companii.ID_companie  =Avioane.ID_companie


SELECT DISTINCT Clase.NUME_CLASA, Companii.nume_companie
FROM Clase
INNER JOIN Bilete ON Bilete.ID_clasa  = Clase.ID_clasa
INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
INNER JOIN Companii ON Companii.ID_companie = Avioane.ID_companie


SELECT Departamente.denumire AS Departament, COUNT(Tasks.ID_task) AS 'Nr tasks'
FROM Departamente
INNER JOIN Functii ON Functii.ID_departament = Departamente.ID_departament
INNER JOIN Repartizare_functii ON Repartizare_functii.ID_functie = Functii.ID_functie
INNER JOIN Staff ON Staff.ID_staff  =Repartizare_functii.ID_staff
INNER JOIN StaffTasks ON Staff.ID_staff = StaffTasks.ID_staff
INNER JOIN Tasks ON Tasks.ID_task = StaffTasks.ID_task
GROUP BY Departamente.denumire

SELECT DISTINCT Companii.nume_companie, Tari.nume_tara
FROM Companii
INNER JOIN Avioane ON Avioane.ID_companie = Companii.ID_companie
INNER JOIN Zboruri ON Zboruri.ID_avion = Avioane.ID_avion
INNER JOIN Aeroporturi ON Aeroporturi.ID_aeroport = Zboruri.ID_aeroport
INNER JOIN Locatii ON Locatii.ID_locatie = Aeroporturi.ID_oras
INNER JOIN Tari ON Tari.ID_tara = Locatii.ID_tara


SELECT TOP 1 c.nume, c.prenume, b.pret_bilet
FROM Calatori c
JOIN Bilete b ON c.ID_calator = b.ID_calator
ORDER BY b.pret_bilet DESC;


SELECT TOP 1 z.ID_zbor, z.durata, t.nume_tara
FROM Zboruri z
JOIN Aeroporturi a ON z.ID_aeroport = a.ID_aeroport
JOIN Locatii l ON a.ID_oras = l.ID_locatie
JOIN Tari t ON l.ID_tara = t.ID_tara
WHERE t.nume_tara = 'Italia'
ORDER BY z.durata DESC;


SELECT MAX(salariu_brut) AS salariu_maxim, nume AS nume_functie
FROM Functii
GROUP BY nume;



SELECT Bilete.pret_bilet, Calatori.nume, Calatori.prenume, Zboruri.ora, Zboruri.durata
FROM Bilete
JOIN Calatori ON Bilete.ID_calator = Calatori.ID_calator
JOIN BiletePerZbor ON Bilete.ID_bilet = BiletePerZbor.ID_bilet
JOIN Zboruri ON BiletePerZbor.ID_zbor = Zboruri.ID_zbor;


IF OBJECT_ID ('ContractesiImpozite', 'V') IS NOT NULL
	DROP VIEW ContractesiImpozite
 	  
GO 
CREATE VIEW ContractesiImpozite
as 
	SELECT Staff.nume, Staff.prenume, Contracte.descriere AS Contract, Impozite.nume AS Impozit
	FROM Functii 
	INNER JOIN Repartizare_functii ON Functii.ID_functie = Repartizare_functii.ID_functie
	INNER JOIN Staff ON Repartizare_functii.ID_staff = Staff.ID_staff
	INNER JOIN Contracte ON Contracte.ID_angajat = Staff.ID_staff
	INNER JOIN ContracteImpozite ON Contracte.ID_contract = ContracteImpozite.ID_contract
	INNER JOIN Impozite ON Impozite.ID_impozit = ContracteImpozite.ID_impozit

	SELECT*
	FROM ContractesiImpozite


IF OBJECT_ID ('Porti', 'V') IS NOT NULL
	DROP VIEW Porti
 	  
GO 
CREATE VIEW Porti
as 
	SELECT Zboruri.*, Gates.numar AS Gate, Gates.capacitate
	FROM Zboruri
	INNER JOIN ZboruriGates ON Zboruri.ID_zbor = ZboruriGates.ID_zbor
	INNER JOIN Gates ON Gates.ID_gate = ZboruriGates.ID_gate

	SELECT*
	FROM Porti

IF OBJECT_ID ('ViewCalatori', 'V') IS NOT NULL
	DROP VIEW ViewCalatori
 	  
GO 
CREATE VIEW ViewCalatori
as 
	SELECT Calatori.nume, Calatori.prenume, Companii.nume_companie AS Companie
	FROM Calatori
	INNER JOIN Bilete ON Bilete.ID_calator = Calatori.ID_calator
	INNER JOIN BiletePerZbor ON BiletePerZbor.id_bilet = Bilete.ID_bilet
	INNER JOIN Zboruri ON Zboruri.ID_zbor = BiletePerZbor.id_zbor
	INNER JOIN Avioane ON Avioane.ID_avion = Zboruri.ID_avion
	INNER JOIN Companii ON Companii.ID_companie = Avioane.ID_companie

	SELECT*
	FROM ViewCalatori



SELECT Bilete.ID_bilet, Calatori.nume, Calatori.prenume, Clase.NUME_CLASA
FROM Bilete
JOIN Calatori ON Bilete.ID_calator = Calatori.ID_calator
JOIN Clase ON Bilete.ID_clasa = Clase.ID_clasa;


select*
from Departamente



SELECT Staff.nume, Staff.prenume, Functii.salariu_brut, Departamente.denumire
FROM Staff
JOIN Repartizare_functii ON Staff.ID_staff = Repartizare_functii.ID_staff
JOIN Functii ON Repartizare_functii.ID_functie = Functii.ID_functie
JOIN Departamente ON Functii.ID_departament = Departamente.ID_departament
WHERE Departamente.denumire = 'Siguranta';


BACKUP DATABASE [GestiuneAeroport3]
TO DISK = N'C:\DataBase3\GestiuneAeroport3.bak' WITH NOFORMAT,
NOINIT, 
NAME = N'GestiuneAeroport3-Full Database Backup',
SKIP,
NOREWIND,
NOUNLOAD,
STATS = 10
GO


BEGIN TRANSACTION;


DECLARE @ID_calator int;
INSERT INTO Calatori (CNP, nume, prenume, sex, email, telefon, adresa)
VALUES ('1234567890183', 'Godina', 'Marius', 'MASCULIN', 'marius@email.com', '0712345679', 'Bucuresti Blvd. Gerge Cosbuc');

SET @ID_calator = SCOPE_IDENTITY();


DECLARE @ID_clasa int;
INSERT INTO Clase (NUME_CLASA)
VALUES ('ECONOMIC');

SET @ID_clasa = SCOPE_IDENTITY();


DECLARE @ID_bilet int;
INSERT INTO Bilete (ID_calator, ID_clasa, pret_bilet)
VALUES (@ID_calator, @ID_clasa, 100);

SET @ID_bilet = SCOPE_IDENTITY();


DECLARE @ID_zbor int;
SET @ID_zbor = 72; -- ID-ul zborului la care doriți să asociați biletul

INSERT INTO BiletePerZbor (id_bilet, id_zbor)
VALUES (@ID_bilet, @ID_zbor);

ROLLBACK TRANSACTION;


select*
from Zboruri
drop trigger  tr_check_telefon

